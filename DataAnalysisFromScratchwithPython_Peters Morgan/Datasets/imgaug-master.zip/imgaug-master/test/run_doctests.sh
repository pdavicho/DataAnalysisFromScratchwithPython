#!/bin/bash
# Note: requires xdoctest 0.7.0
xdoctest imgaug --global-exec="import imgaug as ia\nfrom imgaug import augmenters as iaa"
