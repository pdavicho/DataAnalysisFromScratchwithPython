# Restaurant-Reviews-using-NLP
A simple project in python which reads a tsv file, cleans the restaurant reviews(text), geneartes a bag-of-words model and uses a classifier which tells whether the review is a positive one or a negative one. 
